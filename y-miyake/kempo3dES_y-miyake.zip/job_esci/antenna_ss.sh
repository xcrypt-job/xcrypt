#--------------- nqs_thread.sh ---------------
#  Sample NQS script
#
########## NQS options #########
#
# @$-eo
#
# @$-q ss20001
#
# @$-g ss20001
#
# @$-lp 1
#
# @$-lP 1 
#
# @$-lm 2gb
#
# @$-ls 128mb
#
##########################################
#
set -x
#
#
 FLIB_USE_STACK_INFO=1;export FLIB_USE_STACK_INFO
#
 FLIB_FASTOMP="TRUE";export FLIB_FASTOMP
#
#
# -------------------------------------
#
cd $QSUB_WORKDIR
#
./kempo3D -Wl,-Lu < plasma.inp
#
##########################################
#  --------------------------------------
