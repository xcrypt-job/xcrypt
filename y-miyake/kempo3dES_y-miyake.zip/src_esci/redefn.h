!
#define  xe(m) pxe(1,m)
#define  ye(m) pxe(2,m)
#define  ze(m) pxe(3,m)
#define vxe(m) pxe(4,m)
#define vye(m) pxe(5,m)
#define vze(m) pxe(6,m)

!
#define pex(i,j,k) pebf(1,i,j,k)
#define pey(i,j,k) pebf(2,i,j,k)
#define pez(i,j,k) pebf(3,i,j,k)
#define pbx(i,j,k) pebf(4,i,j,k)
#define pby(i,j,k) pebf(5,i,j,k)
#define pbz(i,j,k) pebf(6,i,j,k)

!
!#define esx(i,j,k) esf(1,i,j,k)
!#define esy(i,j,k) esf(2,i,j,k)
!#define esz(i,j,k) esf(3,i,j,k)

!
#define workq1(i,j,k) workq(1,i,j,k)
#define workq2(i,j,k) workq(2,i,j,k)
#define workq3(i,j,k) workq(3,i,j,k)

!
#define workt1(i,j,k,l) workt(1,i,j,k,l)
#define workt2(i,j,k,l) workt(2,i,j,k,l)
#define workt3(i,j,k,l) workt(3,i,j,k,l)
