!
! header hdf
!
!   ____________________________________________________________
!
!                    H E A D E R   H   D   F
!   ____________________________________________________________
!
!   ............................................................
!   .                                                          .
!   .         common declaration of variables for HDF          .
!   ............................................................
!
!-------------------- common declaration of variables for HDF

    integer(kind=4) :: DFACC_READ, DFACC_WRITE, DFACC_RW, DFACC_CREATE
    integer(kind=4) :: DF_INT4, DF_REAL8
    integer(kind=4) :: irank

    parameter(DFACC_READ=1, DFACC_WRITE=2, DFACC_RW=3, DFACC_CREATE=4)
    parameter(DF_INT4=24, DF_REAL8=6)
    parameter(irank=3)

    integer(kind=4) :: sd_id, sds_id, status
    integer(kind=4),external :: sfstart, sfcreate, sfwdata, sfendacc, sfend
    integer(kind=4) :: datatype, attributus
    integer(kind=4) :: dim(irank),start(irank),edges(irank),stride(irank)
    character(len=7) :: sdname

    integer(kind=4) :: id_sd(90),idim_f(irank),istart(irank),iend_f(irank)
    integer(kind=4) :: istride(irank),idim_t(irank),iend_t(irank)
    integer(kind=4) :: idim_ph(irank),iend_ph(irank),idim_e(irank)
    integer(kind=4) :: iend_e(irank),ieamp(irank),iend_ea(irank)

    common /idnum/  id_sd
    common /hdfcom/ idim_f,istart,iend_f, &
   &                istride,idim_t,iend_t, &
   &                idim_ph,iend_ph, &
   &                idim_e,iend_e, &
   &                ieamp,iend_ea
