!
! header namels
!
!   ____________________________________________________________
!
!                    H E A D E R   N A M E L S
!   ____________________________________________________________
!
!   ............................................................
!   .                                                          .
!   .        header for common declaration of namelist         .
!   ............................................................
!
!-------------------- common declaration of namelist

!  use paramt
!  use allcom
!  implicit real*8 (a-h,o-z)

      namelist /jobcon/ jobnum,nstep,maxt
      namelist /plasma/ wp, wc,cv,phixy,phiz,b0x,b0y,b0z,b0,wpmax
      namelist /tmgrid/ dt,dr, nx,ny,nz
      namelist /system/ nspec,nwave,mltstp,juncan,alpha,ionchg, &
     &                  jxfltr,jyfltr,jzfltr, ipexfl,ipeyfl,ipezfl, &
     &                  nfltrx,nfltry,nfltrz, nbound, &
     &                  nxl,nxr,nyl,nyr,nzl,nzr,imask,npbnd, &
     &                  nflag_ecrct, mtd_vbnd, &
     &                  nx0,nx1,ny0,ny1,nz0,nz1
      namelist /digcon/ ifxyz, ijxyz, itchck, &
     &                  iddiag, iediag, ifdiag, ijdiag, isdiag, &
     &                  ipadig,ipahdf,ipaxyz, ildig, ivdiag, imdig,ikdiag, &
     &                  nvx,nvy,nvz, ikxmax,ikymax,ikzmax
      namelist /intp/   np,qm,path,spa,spe,speth,peth,f, vpa,vpb,vpe, &
     &                  xe0,ye0,ze0, xed,yed,zed, nphi,ndst,ioptd
      namelist /time/   t,dt
      namelist /grid/   dr,nx,ny,nz, dri,si, nxp1,nyp1,nzp1, &
     &                  anx,any,anz, &
     &                  slx,sly,slz, dkx,dky,dkz
      namelist /out/    npsum, np, qm, q, rm, qmr
      namelist /others/ tcs,cs,rimlt,mlt2,mltm1
      namelist /inp/    npin,inpf,inpb,injct,npr,ilb
      namelist /drft/   vd
      namelist /ptcond/ npc,epc2,amu2,sigma,ncond,nxpc1, &
     &                  nypc1,nzpc1,nxpc2,nypc2,nzpc2, &
     &                  mtd_vchg,v_omega,v_max,modeww
      namelist /scrnt/  sjdata, jsn, pbfact
      namelist /dipole/ mode_dipole,gap_amp,f_c,line_mode,n_shth_rgn, &
     &                  i_gap1,i_gap2,j_gap1,j_gap2,k_gap1,k_gap2,w_c, &
     &                  i_gap, j_gap, k_gap
      namelist /emissn/ nflag_emit,nepl,flpf,flpb,qp, &
     &                  abvdem,dnsf,dnsb,ipcpl, &
     &                  xemf,xemb,ymaxe,ymine,zmaxe,zmine, &
     &                  ephiz,ephixy,emitcx,emitcy,emitcz


