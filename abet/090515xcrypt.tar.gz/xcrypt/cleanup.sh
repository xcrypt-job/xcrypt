#!/bin/bash

rm -f trace*.log; rm -rf job[0-9]*; rm -f N05*; rm -rf inv_watch; rm -f foo*

