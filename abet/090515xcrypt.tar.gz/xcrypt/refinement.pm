package refinement;

use function;
use base qw(dry);

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);
#    my $self = $class->SUPER::new();
    my $obj = shift;
    $self->{cnvg} = $obj->{cnvg};
    $self->{exit_cond} = $obj->{exit_cond};
    $self->{change_args} = $obj->{change_args};
    return bless $self, $class;
}

sub start {
    my $self = shift;
    $self->SUPER::start();
}

sub before {
    my $self = shift;
    $self->SUPER::before();
}

sub after {
  my $self = shift;

  $self->SUPER::after();

  until (&{$self->{exit_cond}}(@{$self->{trace}})) {
      my $foo = 'trigger::' . $self->{cnvg};
      my $bar = $$foo;
      my $obj = trigger->new($bar);
      $obj->{id} = $obj->{id} . '_';
      $obj->{args} = &{$self->{change_args}}($obj->{args});
      $obj->{exit_cond} = sub { &function::tautology };
      $obj->{trace} = $self->{trace};
      #��̤������change_input_file �� input_file �򹹿�
      &start($obj);
      $self->{trace} = $obj->{trace};
  }
}

1;
