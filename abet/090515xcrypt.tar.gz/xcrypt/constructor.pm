package constructor;

use base qw(successor);

sub new {
    my $class = shift;
    my $self = $class->SUPER::new(@_);
#    my $self = $class->SUPER::new();
    my $obj = shift;
    $self->{id} = $obj->{id};
    $self->{exe} = $obj->{exe};
    $self->{args} = $obj->{args};
    $self->{trace} = $obj->{trace};
    return bless $self, $class;
}

1;
