#!/usr/bin/perl

package trigger;

use Getopt::Long;
use function;
use threads;
use threads::shared;
use jobsched;
use limit;

use base qw(constructor);

$opt_dry = 0;
GetOptions('dry' => \$opt_dry);

# ̵̾�ϥå����񤫤��� id ���ѿ�̾�Ȥ���ϥå����ե���󥹤�Ĥ��롩
$job0 = {
    'id' => 'job0',
    'option' => '# @$-q eh',
    'exit_cond' => sub { &function::tautology; },
    'successors' => ['job3','job4','job5']
};

$job3 = {
    'id' => 'job3',
    'predecessors' => ['job4','job5'],
    'exe' => './kempo.pl',
    'args' => [50, 100000000],
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'exit_cond' => sub { &function::tautology; },
    'option' => '# @$-q eh'
};


$job4 = {
    'id' => 'job4',
    'cnvg' => 'job1',
    'option' => '# @$-q eh',
    'trace' => [40, 400],
    'exit_cond' => sub { &function::forward_difference; },
    'change_args' => sub { my $aaa = $_[0]; return [$$aaa[0] + 10, 100]; },
    'change_input_file' => sub {}
};

$job5 = {
    'id' => 'job5',
    'cnvg' => 'job2',
    'option' => '# @$-q eh',
    'trace' => [50, 500],
    'exit_cond' => sub { &function::forward_difference; },
    'change_args' => sub { my $aaa = $_[0]; return [$$aaa[0] + 1, 100]; },
    'change_input_file' => sub {}
};

$job1 = {
    'id' => 'job1',
    'predecessors' => [],
    'exe' => './kempo.pl',
    'args' => [20, 100],
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'option' => '# @$-q eh',
    'trace' => [10, 100]
};

$job2 = {
    'id' => 'job2',
    'predecessors' => [],
    'exe' => './kempo.pl',
    'args' => [30, 100],
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'option' => '# @$-q eh',
    'trace' => [20, 200]
};

$limit::smph=Thread::Semaphore->new(6);
trigger->new($job0)->start;

# jobsched.pm �� my �򳰤��ʤ��ȼ���
#$jobsched::inventory_watch_thread->join;
