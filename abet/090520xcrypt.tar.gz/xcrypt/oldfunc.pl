sub parexecnew {
    my $thrd;
    my $thrd_card : shared = 0;
    foreach my $id (@_) {
	&generate($id);
	my $foo = $id . '_init';
	eval "\$bar = \$$foo;";
	my $obj = xcrypt->new($bar);
	$thrd[$thrd_card] = threads->new(\&constructor::start, $obj);
	$thrd_card++;
    }
    for (my $k = 0; $k < $thrd_card; $k++) {
	$thrd[$k]->join;
    }
}

sub parexecnewnew {
    $job0 = {
	'id' => 'job0',
	'option' => '# @$-q eh',
	'exit_cond' => sub { &function::tautology; },
	'successors' => []
    };
    foreach my $id (@_) {
	&generate($id);
	my $init_id = $id . '_init';
	push (@{$job0->{successors}} , $init_id);
    }
    xcrypt->new($job0)->start;
}

sub generatenew {
    my $id = $_[0];
    my $final_id = $id . '_final';
    eval "\$$final_id = {
'id' => '$final_id',
'predecessors' => [],
'option' => '# @$-q eh',
'exit_cond' => sub { &function::tautology; },
'successors' => []
};";
    my $init_id = $id . '_init';
    eval "\$$init_id = {
'id' => '$init_id',
'option' => '# @$-q eh',
'exit_cond' => sub { &function::tautology; },
'successors' => ['$final_id']
};";
    my $jobset = $$id;
    my @params = @{$jobset->{param}};
    foreach $param (@params) {
	unless ($jobset->{amplifier} eq '') {
	    $param = &{$jobset->{amplifier}}($param);
	}
	my $job_id = $id . '_' . $param;
	push (@{$$init_id->{successors}} , $job_id);
	push (@{$$final_id->{predecessors}} , $job_id);
	eval "\$$job_id = {
'id' => '$job_id',
'exe' => '$jobset->{exe}',
'args' => [$param],
'option' => '# @$-q eh',
'input_file' => '$jobset->{input_file}',
'output_file' => '$jobset->{output_file}',
'output_column' => 1,
'delimiter' => ',',
'exit_cond' => sub { &function::tautology; },
};";
    }
    $limit::smph=Thread::Semaphore->new(6);
}
