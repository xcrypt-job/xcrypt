#!/usr/bin/perl

package xcrypt;

use Getopt::Long;
use function;
use threads;
use threads::shared;
use jobsched;
use limit;
use base qw(constructor);

$opt_dry = 0;
GetOptions('dry' => \$opt_dry);

$jobset1 = {
    'exe' => './kempo1.pl',
    'arg1s' => [1..9],
    'amplifier1' => sub { $_[0] + 1; },
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody'
};
$jobset2 = {
    'exe' => './kempo2.pl',
    'arg1s' => [101..109],
    'amplifier1' => sub { $_[0] + 2; },
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody'
};
$jobset3 = {
    'exe' => './kempo3.pl',
    'arg1s' => [201..209],
    'amplifier1' => sub { $_[0] + 3; },
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody'
};

&parexec('jobset1', 'jobset2', 'jobset3');
#&parexecnew('jobset1', 'jobset2', 'jobset3');

sub parexec {
    my $thrd;
    my $thrd_card : shared = 0;
    foreach my $id (@_) {
	my @aaa = &generate($id);
	foreach $bbb (@aaa) {
	    eval "\$ccc = \$$bbb;";
	    my $obj = xcrypt->new($ccc);
	    $thrd[$thrd_card] = threads->new(\&constructor::start, $obj);
	    $thrd_card++;
	}
    }
    for (my $k = 0; $k < $thrd_card; $k++) {
	$thrd[$k]->join;
    }
}

sub generate {
    my $jobset_id = $_[0];
    my $jobset = $$jobset_id;
    my @arg1s = @{$jobset->{arg1s}};
    my @job_ids;
    foreach $arg1 (@arg1s) {
	unless ($jobset->{amplifier1} eq '') {
	    $arg1 = &{$jobset->{amplifier1}}($arg1);
	}
	my $job_id = $jobset_id . '_' . $arg1;
	push (@job_ids , $job_id);
	eval "\$$job_id = {
'id' => '$job_id',
'exe' => '$jobset->{exe}',
'arg1' => $arg1,
'option' => '# @$-q eh',
'input_file' => '$jobset->{input_file}',
'output_file' => '$jobset->{output_file}',
'output_column' => 1,
'delimiter' => ',',
'exit_cond' => sub { &function::tautology; },
};";
    }
    $limit::smph=Thread::Semaphore->new(6);
    return @job_ids;
}

$job0 = {
    'id' => 'job0',
    'option' => '# @$-q eh',
    'exit_cond' => sub { &function::tautology; },
    'successors' => ['job3','job4','job5']
};
$job3 = {
    'id' => 'job3',
    'predecessors' => ['job4','job5'],
    'exe' => './kempo.pl',
    'arg1' => 50,
    'arg2' => 100000000,
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'exit_cond' => sub { &function::tautology; },
    'option' => '# @$-q eh'
};
$job4 = {
    'id' => 'job4',
    'cnvg' => 'job1',
    'option' => '# @$-q eh',
    'trace' => [40, 400],
    'exit_cond' => sub { &function::forward_difference; },
    'change_arg1' => sub { $_[0] + 10; },
    'change_arg2' => sub { 100; },
    'change_input_file' => sub {}
};
$job5 = {
    'id' => 'job5',
    'cnvg' => 'job2',
    'option' => '# @$-q eh',
    'trace' => [50, 500],
    'exit_cond' => sub { &function::forward_difference; },
    'change_arg1' => sub { $_[0] + 1; },
    'change_arg2' => sub { 100; },
    'change_input_file' => sub {}
};
$job1 = {
    'id' => 'job1',
    'predecessors' => [],
    'exe' => './kempo.pl',
    'arg1' => 20,
    'arg2' => 100,
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'option' => '# @$-q eh',
    'trace' => [10, 100]
};
$job2 = {
    'id' => 'job2',
    'predecessors' => [],
    'exe' => './kempo.pl',
    'arg1' => 30,
    'arg2' => 100,
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'option' => '# @$-q eh',
    'trace' => [20, 200]
};
#    $limit::smph=Thread::Semaphore->new(6);
#    xcrypt->new($job0)->start;
