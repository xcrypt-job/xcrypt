package parents;

use limit;

@ISA = (limit);

sub start {
    my $self = shift;
    $self->SUPER::start();
}

sub before {
    my $self = shift;
    foreach my $parent (@{$self->{parents}}) {
	my $file = 'dir_' . $parent. '/destruction';
	until ( -e $file ) {
	    sleep(5);
	}
    }
    $self->SUPER::before();
}

sub after {
    my $self = shift;
    $self->SUPER::after();
}

1;
