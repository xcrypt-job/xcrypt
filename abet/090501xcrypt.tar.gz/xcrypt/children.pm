package children;

use threads;
use threads::shared;

use parents;

@ISA = (parents);

sub new {
    my $class = shift;
#    my $self = $class->SUPER::new();
    my $self = shift;
    return bless $self, $class;
}

sub start {
    my $self = shift;
    $self->SUPER::start();
}

sub before {
    my $self = shift;
    $self->SUPER::before();
}

sub after {
  my $self = shift;
  my $thrd;
  my $thrd_card : shared = 0;

  $self->SUPER::after();

  if (&{$self->{exit_cond}}(@{$self->{trace}})) {
      my $hoge = @{$self->{children}};
      if ($hoge == 0) {
	  open ( TRACE , '>> trace.log' );
	  print TRACE join (' ', @{$self->{trace}}), "\n";
	  close ( TRACE );
      }
      foreach my $child (@{$self->{children}}) {
	  my $foo = 'trigger::' . $child;
	  my $bar = $$foo;
	  my $obj = children->new($bar);
	  $obj->{trace} = $self->{trace};
	  $thrd[$thrd_card] = threads->new(\&start, $obj);
	  $thrd_card++;
      }
      for (my $k = 0; $k < $thrd_card; $k++) {
	  $thrd[$k]->join;
      }
  }
  else {
      my $obj = children->new($self);
      $obj->{id} = $self->{id} . "_0";
      $obj->{arg} = &{$self->{change_arg}}($self->{arg});
      # change_input_file �� input_file �򹹿�
      &start($obj);
  }
}

1;
