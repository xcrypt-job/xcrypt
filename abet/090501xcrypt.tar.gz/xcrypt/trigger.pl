#!/usr/bin/perl

package trigger;

use function;
use children;

@ISA = (children);

$job_0 = {
    'id' => 'job_0',
    'parents' => [],
    'exe' => './foo',
    'arg' => '',
    'input_file' => '',
    'output_file' => 'bar',
    'output_column' => 1,
    'delimiter' => ',',
    'verbose' => 1,
    'verbose_node' => 1,
    'queue' => 'eh',
    'process' => 1,
    'cpu' => 1,
    'memory' => '1gb',
    'exit_cond' => sub { &function::tautology; },
    'limit' => 3,
    'children' => ['job_0_0','job_0_1','job_0_2']
};

$job_0_0 = {
    'id' => 'job_0_0',
    'parents' => ['job_0_1','job_0_2'],
    'exe' => './kempo.pl',
    'arg' => 200,
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'verbose' => 1,
    'verbose_node' => 1,
    'queue' => 'eh',
    'process' => 2,
    'cpu' => 4,
    'memory' => '1gb',
    'exit_cond' => sub { &function::forward_difference; },
    'change_arg' => sub { $_[0] + 1; },
    'change_input_file' => sub {},
    'limit' => 3,
    'children' => []
};


$job_0_1 = {
    'id' => 'job_0_1',
    'parents' => [],
    'exe' => './kempo.pl',
    'arg' => 20,
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'verbose' => 1,
    'verbose_node' => 1,
    'queue' => 'eh',
    'process' => 2,
    'cpu' => 4,
    'memory' => '1gb',
    'exit_cond' => sub { &function::forward_difference; },
    'change_arg' => sub { $_[0] + 10; },
    'change_input_file' => sub {},
    'limit' => 3,
    'children' => []
};

$job_0_2 = {
    'id' => 'job_0_2',
    'parents' => [],
    'exe' => './kempo.pl',
    'arg' => 100,
    'input_file' => 'plasma.inp',
    'output_file' => 'pbody',
    'output_column' => 1,
    'delimiter' => ',',
    'verbose' => 1,
    'verbose_node' => 1,
    'queue' => 'eh',
    'process' => 2,
    'cpu' => 4,
    'memory' => '1gb',
    'exit_cond' => sub { &function::forward_difference; },
    'change_arg' => sub { $_[0] + 5; },
    'change_input_file' => sub {},
    'limit' => 3,
    'children' => []
};

trigger->new($job_0)->start;

# �ʲ��ϳФ���
#&gen_job_seq(2, 1000, '2 *', '2 +');
sub gen_job_seq {
    for (my $i = $_[0]; $i <= $_[1]; $i++) {
	my $hoge = {
	    'id' => $i,
	    'parents' => [],
	    'exe' => './kempo.pl',
	    'arg' => eval($_[2] . $i),
	    'input_file' => 'plasma.inp',
	    'output_file' => 'pbody',
	    'verbose' => 1,
	    'verbose_node' => 1,
	    'queue' => 'eh',
	    'process' => 2,
	    'cpu' => 4,
	    'memory' => '1gb',
	    'exit_cond' => sub { &function::forward_difference; },
	    'limit' => 3,
#	    'children' => [eval($_[3] . $i)]
	    'children' => []
	};
    eval "\$job$i = \$hoge";
    }
}
