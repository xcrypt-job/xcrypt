#!/bin/bash

rm -f trace.log
rm -rf dir_*; rm -f N05*

